import os
from flask import Flask, request

app = Flask(__name__)


@app.route('/densepose', methods=['POST'])
def dense():
    content = request.get_json()
    dense_root_dir = content["DenseRootDir"]

    #ClientDense-DenseFolder
    if not os.path.exists(os.path.join(dense_root_dir,content["ClientID"])):
        os.mkdir(os.path.join(dense_root_dir,content["ClientID"]))

    #Image-ImageFolder
    if not os.path.exists(os.path.join(dense_root_dir,content["ClientID"],content["FileName"])):
        os.mkdir(os.path.join(dense_root_dir,content["ClientID"],content["FileName"]))
        dense_path = os.path.join(dense_root_dir, content["ClientID"], content["FileName"])
        print(dense_path)

    os.system(f'python3 apply_net.py show --output "{dense_path+"/"+content["ClientID"]}.jpg"  configs/densepose_rcnn_R_101_FPN_DL_s1x.yaml  https://dl.fbaipublicfiles.com/densepose/densepose_rcnn_R_101_FPN_DL_s1x/165712116/model_final_844d15.pkl "{content["ImagePath"]}/" dp_segm -v')
    # os.system('python apply_net.py show --output "./Output_image/im.jpg"  configs/densepose_rcnn_R_101_FPN_DL_s1x.yaml  https://dl.fbaipublicfiles.com/densepose/densepose_rcnn_R_101_FPN_DL_s1x/165712116/model_final_844d15.pkl "./Input_image/*.jpg" dp_segm -v')

    return "DensePose Generated"


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081, debug=False)



